 function f()
 {
  var person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};

    document.getElementById("demo").innerHTML =
            person.firstName + " is " + person.age + " years old.";
            }