/**
 * Created by ssavaira on 5/19/2015.
 */
'use strict';

var eventsApp= angular.module('eventsApp', ['ngResource', 'ngRoute'])
    .config(function($routeProvider){
        $routeProvider.when('/home',{

            templateUrl:'page1.html'//,
            //controller: 'EditEventController'

        });

        $routeProvider.when('/regForm',{

            templateUrl:'page2.html'//,
            //controller: 'EventController'
        });

        $routeProvider.otherwise({redirectTo:'/home'});

        console.log('App called.');
    });