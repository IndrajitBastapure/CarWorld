
rentCarApp.controller('rentCarController',function($scope,rentCarData,$http)
{
    $scope.visible = false;
    $scope.visible1 = false;


    $scope.toggle = function(inf,inf1) {

        $scope.flag=1;
        console.log(inf);
        console.log(inf1);


          $scope.visible = !$scope.visible;
              $scope.visible=true;
        $scope.cars=inf;

        $scope.master=inf;



        var a = {};
        a.car = inf;
        a.city = inf1;
console.log('hi dubey');
       console.log(a)
        console.log($scope.master);
        $http({
            method: 'POST',
            url: 'http://localhost:8083/CarWorld/carBodyInfo',
            headers: {'Content-Type': 'application/json'},
            data:a



        }).success(function (data)
        {
            $scope.carInfo=data;

            console.log("fetch rent car : ");


            console.log($scope.carInfo)
        });



    },
        /**********************************************/

        $scope.toggle1 = function() {
            $scope.visible1 = !$scope.visible1;


        },



        rentCarData.getCities(function(cities)
        {

            $scope.cities=cities;
            console.log($scope.cities)

        });




    $scope.master = {};

    $scope.saveCity = function(car)
    {
        $scope.master = angular.copy(car);
       console.log('hi in save city');
        console.log($scope.master)
        $http({
            method: 'POST',
            url: 'http://localhost:8083/CarWorld/carType',
            headers: {'Content-Type': 'application/json'},
            data:$scope.master



        }).success(function (data)
        {
            $scope.carTypes=data;
            console.log($scope.carTypes)
        });
    };






});
