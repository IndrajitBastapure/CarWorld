'use strict'
var rentCarApp=angular.module('RentCarApp',[]);
