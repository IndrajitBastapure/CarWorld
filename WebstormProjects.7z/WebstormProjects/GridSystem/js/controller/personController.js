personApp.controller('personController',function($scope) {
    $scope.persons = [
        {
            firstName: 'Ajinkya',
            LastName: 'Rahane',
            Age: 40,
            images: 'image/ajinkya.jpg',
            date:new Date()
        },
        {
            firstName: 'Virendra',
            LastName :'Sehwag',
            Age:43,
            images:'image/sehwag.jpg',
            date:new Date()
        },
        {
            firstName: 'Zaheer',
            LastName :'Khan',
            Age:35,
            images:'image/zaheer.jpg',
            date:new Date()
        },
        {
            firstName: 'Gabbar',
            LastName :'singh',
            Age:43,
            images:'image/1.jpg',
            date:new Date()
        },
        {
            firstName: 'Amit',
            LastName :'Bachchan',
            Age:43,
            images:'image/jai.jpg',
            date:new Date()
        },
        {
            firstName: 'Dharam',
            LastName :'paji',
            Age:43,
            images:'image/veeru.jpg',
            date:new Date()
        }

    ],
         $scope.AscendingfirstName=function()
    {
        $scope.sortOrder='firstName'
    }

    $scope.DescendingfirstName=function()
    {
        $scope.sortOrder='-firstName'
    }




});

