'use strict';
var personApp=angular.module('personApp',[]);
