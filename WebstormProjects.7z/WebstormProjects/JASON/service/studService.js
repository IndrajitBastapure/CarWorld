studApp.factory('studData',function($http){

    return{
        getStudents: function (students) {
            var url = "http://localhost:63342/JASON/data.json";
            $http.get(url).success(function(response) {
                students(response.stud);
            });
        }
    }

});