/*function studentController($scope,$http)
{
    var url="data.json";
    $http.get(url).success( function(response) {
        $scope.students = response;
    });
}*/
/*
$scope.otherStuff = {};
jsonFactory.getOtherStuff()
    .then(function (response) {
        $scope.students = response.data.components;
    }, function (error) {
        console.error(error);
    });

 */

studApp.controller('studController',function($scope,studData){
   studData.getStudents(function(students){
        $scope.students=students;
    });
});