'use strict'
var studApp=angular.module('StudApp',[]);
