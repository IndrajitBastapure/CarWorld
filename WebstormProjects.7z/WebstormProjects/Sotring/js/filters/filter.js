/**
 * Created by nkolte on 5/7/2015.
 */
'use strict'
personApp.filter('gender',function(){
    return function(gender,person){
        console.log(person.gender)
        if(gender=='male'){
            return '+' +person.firstName;
        }
        else
        {
            return '*' +person.firstName;
        }
    }
})
