/**
 * Created by nkolte on 5/6/2015.
 */
personApp.controller('personController',function($scope) {
    $scope.persons = [
        {
            id: 0,
            firstName: 'Nitin',
            lastName: 'Kolte',
            age: 24,
            gender: 'male',
            emp: 'employed',
            mStatus: 'Unmarried',
            dob: '18-Oct-1990',
            image: 'images/nitin/i2.jpg',
            imgArr: ['images/nitin/i2.jpg', 'images/nitin/a1.jpg', 'images/nitin/a2.jpg', 'images/nitin/a3.jpg', 'images/nitin/a4.jpg']
        },

        {
            id: 1,
            firstName: 'Akshay',
            lastName: 'Kharche',
            age: 22,
            gender: 'male',
            emp: 'employed',
            mStatus: 'Unmarried',
            dob: '20-Dec-1991',
            image: 'images/akshay/i1.jpg',
            imgArr: ['images/akshay/i1.jpg']
        },

        {
            id: 3,
            firstName: 'Sachin',
            lastName: 'Sonawane',
            age: 23,
            gender: 'male',
            emp: 'employed',
            mStatus: 'Unmarried',
            dob: '20-Dec-1991',
            image: 'images/sachin/i3.jpg',
            imgArr: ['images/sachin/i3.jpg']
        },

        {
            id: 4,
            firstName: 'Swapnil',
            lastName: 'Koche',
            age: 20,
            gender: 'male',
            emp: 'employed',
            mStatus: 'Unmarried',
            dob: '22-Jan-1992',
            image: 'images/swapnil/i4.jpg',
            imgArr: ['images/swapnil/i4.jpg']
        },

        {
            id: 5,
            firstName: 'Akshata',
            lastName: 'G',
            age: 20,
            gender: 'female',
            emp: 'employed',
            mStatus: 'married',
            dob: '22-Jan-1992',
            image: 'images/akshata/ak.jpg',
            imgArr: ['images/akshata/ak.jpg']
        },

        {
            id: 5,
            firstName: 'Ramya',
            lastName: 'P',
            age: 20,
            gender: 'female',
            emp: 'employed',
            mStatus: 'married',
            dob: '23-dec-1992',
            image: 'images/ramya/rm.jpg',
            imgArr: ['images/ramya/rm.jpg']
        }
    ],
        $scope.sorting = function (argument){
            $scope.sortData = argument
        }
});
