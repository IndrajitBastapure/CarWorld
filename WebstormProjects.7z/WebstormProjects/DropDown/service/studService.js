studApp.factory('studData',function($http){

    return{
        getStudents: function (students) {
            var url = "http://localhost:8083/JSON/JServlet";
            $http.get(url).success(function(response) {
                students(response);
            });
        }
    }

});

/*
studApp.controller ('salController', function($scope, $http)
{
    $scope.master = {};

    $scope.save = function(stud)
    {
        $scope.master = angular.copy(stud);
        console.log($scope.master);
        $http({
            method: 'POST',
            url: 'http://localhost:8083/JSON/abc',
            headers: {'Content-Type': 'application/json'},
            data:  $scope.master
        }).success(function (data)
        {
            $scope.status=data;
        });
    };
});


*/
