/*function studentController($scope,$http)
{
    var url="data.json";
    $http.get(url).success( function(response) {
        $scope.students = response;
    });
}*/
/*
$scope.otherStuff = {};
jsonFactory.getOtherStuff()
    .then(function (response) {
        $scope.students = response.data.components;
    }, function (error) {
        console.error(error);
    });

 */

studApp.controller('studController',function($scope,studData,$http)
{
   studData.getStudents(function(students)
   {
        $scope.students=students;
       console.log($scope.students)

   });
    $scope.master = {};

    $scope.save = function(stud)
    {
         $scope.master = angular.copy(stud);
         console.log( $scope.master)

        $http({
            method: 'POST',
            url: 'http://localhost:8083/JSON/abc',
            headers: {'Content-Type': 'application/json'},
            data:$scope.master

        }).success(function (data)
        {
            $scope.lastNames=data;
            console.log($scope.lastNames)
        });
    };

});

