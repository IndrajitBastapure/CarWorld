carApp.factory('carData',function($http){

    return{
        getCities: function (cars) {
            var url = "http://localhost:8083/CarWorld/findCity";

            $http.get(url).success(function (response) {
                cars(response);
            });
        }}

});


