
carApp.controller('carController',function($scope,carData,$http)
{
    $scope.visible = false;
    $scope.visible1 = false;

    $scope.toggle = function(inf,brand)
    {

        console.log(inf);



        $scope.visible = !$scope.visible;
        $scope.visible=true;
        $scope.dealersInfo=inf;

       $scope.brand=brand;

        var a={};
        a.brand=$scope.brand;
        a.dealer=inf;

        console.log(a);

        $http({
            method: 'POST',
            url: 'http://localhost:8083/CarWorld/findDealerModel',
            headers: {'Content-Type': 'application/json'},
            data:a



        }).success(function (data)
        {
            $scope.modelInfo=data;

            console.log("fetch model : ");
            console.log($scope.modelInfo)
        });




    },

        $scope.toggle1 = function() {
            $scope.visible1 = !$scope.visible1;


        },



        carData.getCities(function(cities)
        {

            $scope.cities=cities;
            console.log($scope.cities)

        });




    $scope.master = {};

    $scope.saveCity = function(car)
    {
        $scope.master = angular.copy(car);

        console.log($scope.master)
        $http({
            method: 'POST',
            url: 'http://localhost:8083/CarWorld/findBrand',
            headers: {'Content-Type': 'application/json'},
            data:$scope.master



        }).success(function (data)
        {
            $scope.brands=data;
            console.log($scope.brands)
        });
    };




    $scope.master = {};

    $scope.saveBrand = function(car)
    {
        $scope.master = angular.copy(car);

        console.log($scope.master)
        $http({
            method: 'POST',
            url: 'http://localhost:8083/CarWorld/findDealer',
            headers: {'Content-Type': 'application/json'},
            data:$scope.master



        }).success(function (data)
        {
            $scope.dealers=data;
            console.log($scope.dealers)
        });
    };

});
