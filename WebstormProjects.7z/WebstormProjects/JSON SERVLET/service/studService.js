studApp.factory('studData',function($http){

    return{
        getStudents: function (students) {
            var url = "http://localhost:8083/JSON/JServlet";
            $http.get(url).success(function(response) {
                students(response);
            });
        }
    }

});